"""
app.py — The main server for your trading bot dashboard.
Run this file to start the web app: python app.py
Then open http://localhost:5000 in your browser.
"""

from flask import Flask, render_template, jsonify
from datetime import datetime
import database
import strategy
import data_fetcher

app = Flask(__name__)

# ─── Pages ────────────────────────────────────────────────────────────────────

@app.route("/")
def dashboard():
    """Main dashboard page."""
    return render_template("dashboard.html")

# ─── API endpoints (called by the dashboard to get live data) ─────────────────

@app.route("/api/summary")
def api_summary():
    """
    Returns a summary card for the top of the dashboard:
    - Total bot portfolio value
    - Total profit or loss in rupees
    - Total profit or loss as a percentage
    - Whether the bot is active today or paused (daily loss limit hit)
    """
    trades = database.get_all_trades()
    holdings = database.get_open_positions()

    invested = sum(t["buy_price"] * t["quantity"] for t in holdings)
    current_value = 0
    for h in holdings:
        price = data_fetcher.get_current_price(h["symbol"])
        current_value += price * h["quantity"]

    closed_pnl = sum(t["pnl"] for t in trades if t["status"] == "CLOSED")
    open_pnl = current_value - invested
    total_pnl = closed_pnl + open_pnl

    starting_capital = 20000
    total_pnl_pct = (total_pnl / starting_capital) * 100

    daily_loss = database.get_todays_loss()
    bot_paused = daily_loss <= -1000  # Pause if lost ₹1000 today

    return jsonify({
        "portfolio_value": round(starting_capital + total_pnl, 2),
        "total_pnl": round(total_pnl, 2),
        "total_pnl_pct": round(total_pnl_pct, 2),
        "invested_amount": round(invested, 2),
        "cash_available": round(starting_capital - invested + closed_pnl, 2),
        "bot_status": "PAUSED — Daily loss limit hit" if bot_paused else "ACTIVE",
        "bot_paused": bot_paused,
        "as_of": datetime.now().strftime("%d %b %Y, %I:%M %p")
    })


@app.route("/api/holdings")
def api_holdings():
    """
    Returns your currently open positions (stocks the bot is holding right now).
    For each stock, shows: name, quantity, what you paid, current price, profit/loss.
    """
    holdings = database.get_open_positions()
    result = []
    for h in holdings:
        current_price = data_fetcher.get_current_price(h["symbol"])
        buy_value = h["buy_price"] * h["quantity"]
        current_value = current_price * h["quantity"]
        pnl = current_value - buy_value
        pnl_pct = (pnl / buy_value) * 100

        result.append({
            "symbol": h["symbol"],
            "quantity": h["quantity"],
            "buy_price": h["buy_price"],
            "current_price": round(current_price, 2),
            "invested": round(buy_value, 2),
            "current_value": round(current_value, 2),
            "pnl": round(pnl, 2),
            "pnl_pct": round(pnl_pct, 2),
            "stop_loss": round(h["buy_price"] * 0.96, 2),   # -4% stop loss
            "target": round(h["buy_price"] * 1.10, 2),       # +10% target
            "days_held": h["days_held"],
            "buy_date": h["buy_date"]
        })
    return jsonify(result)


@app.route("/api/trade_history")
def api_trade_history():
    """
    Returns a list of all completed (closed) trades.
    Shows what was bought, when, sold when, and final profit/loss.
    """
    trades = database.get_closed_trades()
    return jsonify(trades)


@app.route("/api/signals")
def api_signals():
    """
    Runs the strategy scanner RIGHT NOW and returns stocks that
    the bot would consider buying today (based on breakout + volume + RSI).
    These are suggestions only — no orders are placed automatically yet.
    """
    signals = strategy.scan_for_signals()
    return jsonify(signals)


@app.route("/api/portfolio_chart")
def api_portfolio_chart():
    """
    Returns day-by-day portfolio value history for the chart.
    """
    history = database.get_portfolio_history()
    return jsonify(history)


@app.route("/api/run_scan", methods=["POST"])
def api_run_scan():
    """
    Manually trigger a strategy scan.
    In paper trading mode, logs what the bot WOULD do without placing real orders.
    """
    signals = strategy.scan_for_signals()
    for signal in signals:
        database.log_signal(signal)
    return jsonify({"message": f"Scan complete. Found {len(signals)} signals.", "signals": signals})


if __name__ == "__main__":
    database.init_db()  # Create database tables if they don't exist
    print("\n✅ Trading Bot Dashboard is running!")
    print("👉 Open http://localhost:5000 in your browser")
    print("📱 On your phone (same WiFi): http://<your-laptop-ip>:5000\n")
    app.run(debug=True, host="0.0.0.0", port=5000)
