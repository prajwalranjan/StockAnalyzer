"""
strategy.py — The brain of the bot. Decides when to buy and sell.

STRATEGY: Momentum + Breakout
─────────────────────────────
BUY when ALL of these are true:
  1. Stock price breaks above its 20-day high (breakout)
  2. Today's volume is 1.5x the 20-day average (real buying interest)
  3. RSI is between 55 and 75 (strong momentum, not overbought)

SELL when ANY of these happen:
  1. Price drops 4% below your buy price (stop loss — limits your loss)
  2. Price rises 10% above your buy price (take profit — lock in gains)
  3. Stock has been held for 7 days without moving (time stop)
"""

import pandas as pd
import data_fetcher


def calculate_rsi(prices: pd.Series, period: int = 14) -> float:
    """
    RSI = Relative Strength Index.
    A number from 0 to 100 that measures momentum.
    
    Below 30 = oversold (beaten down, may bounce)
    30–55    = neutral
    55–75    = strong uptrend (our sweet spot for buying)
    Above 75 = overbought (may be due for a pullback)
    """
    delta = prices.diff()
    gain = delta.where(delta > 0, 0).rolling(window=period).mean()
    loss = -delta.where(delta < 0, 0).rolling(window=period).mean()
    rs = gain / loss
    rsi = 100 - (100 / (1 + rs))
    return round(float(rsi.iloc[-1]), 2)


def calculate_signals_for_stock(symbol: str) -> dict | None:
    """
    Analyses a single stock and returns a signal if it meets our buy criteria.
    Returns None if the stock doesn't qualify.
    """
    df = data_fetcher.get_historical_data(symbol, period="3mo")

    # Need at least 25 days of data
    if df.empty or len(df) < 25:
        return None

    close = df["Close"]
    volume = df["Volume"]

    # ── Condition 1: Breakout ──────────────────────────────────────────────
    # Today's close is higher than the highest close of the previous 20 days
    prev_20_high = close.iloc[-21:-1].max()
    today_close = float(close.iloc[-1])
    is_breakout = today_close > prev_20_high

    # ── Condition 2: Volume confirmation ──────────────────────────────────
    # Today's volume is at least 1.5x the 20-day average
    avg_volume = float(volume.iloc[-21:-1].mean())
    today_volume = float(volume.iloc[-1])
    volume_ratio = round(today_volume / avg_volume, 2) if avg_volume > 0 else 0
    is_high_volume = volume_ratio >= 1.5

    # ── Condition 3: RSI in sweet spot ────────────────────────────────────
    rsi = calculate_rsi(close)
    is_rsi_good = 55 <= rsi <= 75

    # ── All 3 conditions must be true ─────────────────────────────────────
    if is_breakout and is_high_volume and is_rsi_good:
        return {
            "symbol": symbol,
            "close_price": round(today_close, 2),
            "rsi": rsi,
            "volume_ratio": volume_ratio,
            "prev_20_high": round(float(prev_20_high), 2),
            "signal": "BUY",
            # How much you'd invest and how many shares at ₹5000 per position
            "position_size": 5000,
            "quantity": int(5000 / today_close),
            "stop_loss": round(today_close * 0.96, 2),    # -4%
            "target": round(today_close * 1.10, 2),        # +10%
            "reason": f"Breakout above ₹{round(float(prev_20_high), 2)} with {volume_ratio}x volume and RSI {rsi}"
        }

    return None


def scan_for_signals() -> list:
    """
    Scans the entire stock universe and returns all stocks
    that meet our buy criteria right now.
    
    This is what the bot runs every morning at market open.
    """
    print(f"🔍 Scanning {len(data_fetcher.STOCK_UNIVERSE)} stocks...")
    signals = []

    for symbol in data_fetcher.STOCK_UNIVERSE:
        try:
            signal = calculate_signals_for_stock(symbol)
            if signal:
                signals.append(signal)
                print(f"  ✅ Signal found: {symbol} @ ₹{signal['close_price']}")
        except Exception as e:
            print(f"  ⚠️  Skipped {symbol}: {e}")

    print(f"✅ Scan complete. {len(signals)} signal(s) found.")
    return signals


def check_exit_conditions(symbol: str, buy_price: float, buy_date: str, days_held: int) -> dict | None:
    """
    Checks if a stock we're holding should be sold.
    Returns a sell signal if any exit condition is met, otherwise None.
    """
    current_price = data_fetcher.get_current_price(symbol)
    if current_price == 0:
        return None

    change_pct = ((current_price - buy_price) / buy_price) * 100

    # Stop loss: price fell 4% below what we paid
    if change_pct <= -4:
        return {
            "symbol": symbol,
            "action": "SELL",
            "reason": f"🛑 Stop loss triggered — down {round(change_pct, 1)}%",
            "current_price": current_price,
            "pnl_pct": round(change_pct, 2)
        }

    # Take profit: price rose 10% above what we paid
    if change_pct >= 10:
        return {
            "symbol": symbol,
            "action": "SELL",
            "reason": f"✅ Profit target hit — up {round(change_pct, 1)}%",
            "current_price": current_price,
            "pnl_pct": round(change_pct, 2)
        }

    # Time stop: held for 7+ days without hitting either target
    if days_held >= 7:
        return {
            "symbol": symbol,
            "action": "SELL",
            "reason": f"⏱️ Time stop — held {days_held} days without target hit",
            "current_price": current_price,
            "pnl_pct": round(change_pct, 2)
        }

    return None  # Hold — no exit condition met
