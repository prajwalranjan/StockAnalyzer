"""
database.py — Saves and retrieves all your trade data.
Uses SQLite — a simple database stored as a single file (trading_bot.db).
No server needed, no setup. It just works.
"""

import sqlite3
from datetime import datetime, date

DB_FILE = "trading_bot.db"


def get_connection():
    """Opens a connection to the database file."""
    conn = sqlite3.connect(DB_FILE)
    conn.row_factory = sqlite3.Row  # Lets us access columns by name
    return conn


def init_db():
    """
    Creates the database tables if they don't exist yet.
    Called once when the app starts.
    """
    conn = get_connection()
    c = conn.cursor()

    # Table: every trade the bot makes (or simulates)
    c.execute("""
        CREATE TABLE IF NOT EXISTS trades (
            id          INTEGER PRIMARY KEY AUTOINCREMENT,
            symbol      TEXT NOT NULL,          -- e.g. "RELIANCE.NS"
            quantity    INTEGER NOT NULL,        -- how many shares
            buy_price   REAL NOT NULL,           -- price when bought
            sell_price  REAL,                    -- price when sold (null if still holding)
            buy_date    TEXT NOT NULL,           -- date bought
            sell_date   TEXT,                    -- date sold
            status      TEXT DEFAULT 'OPEN',     -- OPEN or CLOSED
            pnl         REAL DEFAULT 0,          -- profit or loss in ₹
            mode        TEXT DEFAULT 'PAPER'     -- PAPER (simulation) or LIVE
        )
    """)

    # Table: daily portfolio value snapshot (for the chart)
    c.execute("""
        CREATE TABLE IF NOT EXISTS portfolio_history (
            id      INTEGER PRIMARY KEY AUTOINCREMENT,
            date    TEXT NOT NULL,
            value   REAL NOT NULL
        )
    """)

    # Table: signals the bot detected (buy opportunities)
    c.execute("""
        CREATE TABLE IF NOT EXISTS signals (
            id          INTEGER PRIMARY KEY AUTOINCREMENT,
            symbol      TEXT NOT NULL,
            signal_date TEXT NOT NULL,
            rsi         REAL,
            volume_ratio REAL,
            close_price REAL,
            acted_on    INTEGER DEFAULT 0    -- 1 if bot bought this
        )
    """)

    conn.commit()
    conn.close()
    print("✅ Database ready.")


# ─── Trade functions ──────────────────────────────────────────────────────────

def get_open_positions():
    """Returns all stocks the bot is currently holding."""
    conn = get_connection()
    rows = conn.execute("""
        SELECT *, 
               CAST(julianday('now') - julianday(buy_date) AS INTEGER) as days_held
        FROM trades 
        WHERE status = 'OPEN'
        ORDER BY buy_date DESC
    """).fetchall()
    conn.close()
    return [dict(r) for r in rows]


def get_closed_trades():
    """Returns all completed trades with their final profit/loss."""
    conn = get_connection()
    rows = conn.execute("""
        SELECT * FROM trades 
        WHERE status = 'CLOSED'
        ORDER BY sell_date DESC
    """).fetchall()
    conn.close()
    return [dict(r) for r in rows]


def get_all_trades():
    """Returns every trade (open and closed)."""
    conn = get_connection()
    rows = conn.execute("SELECT * FROM trades").fetchall()
    conn.close()
    return [dict(r) for r in rows]


def add_trade(symbol, quantity, buy_price, mode="PAPER"):
    """Records a new buy order."""
    conn = get_connection()
    conn.execute("""
        INSERT INTO trades (symbol, quantity, buy_price, buy_date, status, mode)
        VALUES (?, ?, ?, ?, 'OPEN', ?)
    """, (symbol, quantity, buy_price, date.today().isoformat(), mode))
    conn.commit()
    conn.close()


def close_trade(trade_id, sell_price):
    """Records a sell order and calculates profit/loss."""
    conn = get_connection()
    trade = conn.execute("SELECT * FROM trades WHERE id = ?", (trade_id,)).fetchone()
    pnl = (sell_price - trade["buy_price"]) * trade["quantity"]
    conn.execute("""
        UPDATE trades 
        SET sell_price = ?, sell_date = ?, status = 'CLOSED', pnl = ?
        WHERE id = ?
    """, (sell_price, date.today().isoformat(), pnl, trade_id))
    conn.commit()
    conn.close()
    return pnl


def get_todays_loss():
    """Returns total P&L for trades closed today (used to check daily loss limit)."""
    conn = get_connection()
    row = conn.execute("""
        SELECT COALESCE(SUM(pnl), 0) as total
        FROM trades 
        WHERE status = 'CLOSED' AND sell_date = ?
    """, (date.today().isoformat(),)).fetchone()
    conn.close()
    return row["total"]


# ─── Portfolio history ────────────────────────────────────────────────────────

def save_portfolio_value(value):
    """Saves today's portfolio value for the chart."""
    conn = get_connection()
    today = date.today().isoformat()
    # Only save once per day
    existing = conn.execute(
        "SELECT id FROM portfolio_history WHERE date = ?", (today,)
    ).fetchone()
    if not existing:
        conn.execute("INSERT INTO portfolio_history (date, value) VALUES (?, ?)", (today, value))
        conn.commit()
    conn.close()


def get_portfolio_history():
    """Returns the portfolio value history for the chart."""
    conn = get_connection()
    rows = conn.execute(
        "SELECT date, value FROM portfolio_history ORDER BY date ASC"
    ).fetchall()
    conn.close()
    return [dict(r) for r in rows]


# ─── Signals ──────────────────────────────────────────────────────────────────

def log_signal(signal):
    """Saves a detected buy signal to the database."""
    conn = get_connection()
    conn.execute("""
        INSERT INTO signals (symbol, signal_date, rsi, volume_ratio, close_price)
        VALUES (?, ?, ?, ?, ?)
    """, (
        signal["symbol"],
        date.today().isoformat(),
        signal.get("rsi"),
        signal.get("volume_ratio"),
        signal.get("close_price")
    ))
    conn.commit()
    conn.close()
